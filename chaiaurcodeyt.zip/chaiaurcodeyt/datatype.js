"use strict"; // treat all js code as newr version
//alert(3 + 3); we are using nodejs not browser 
// code should be write in a way look like readable

let name = "Nikki";
let age = 30;
let isloggedIn = false;
let state = null;
console.log(typeof undefined); // type of undefined is undefind
console.log(typeof null); //typeof null is not null but its object in js




// number => 2 to power 53 or 52
// bigInt = for larger number
// string = ""
// boolean = true/false
// null => stand alone value
// undefined => eclared but not assigned any value
// symbol => unique

//object
//array 