const accountId = 12345;
let email = "abc@google.com";
var accountPassword = "123";
acountCity = "Jaipur"
let accountState;
//noaccountId = 43211;
email = "example@gmail.com";
accountPassword = "567";
acountCity = "Raipur"
console.log(accountId);
console.log(email);
console.log(accountPassword);
console.log(acountCity);
console.table([accountId,email,accountPassword,acountCity,accountState]);

/*
Please don't prefer var because of issue of block scope and functional scope
*/

